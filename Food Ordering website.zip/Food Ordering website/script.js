// script.js

document.addEventListener("DOMContentLoaded", () => {
    // Dark/Light Mode Toggle
    const themeToggle = document.createElement("button");
    themeToggle.innerText = "Toggle Dark Mode";
    themeToggle.classList.add("theme-toggle");
    document.body.appendChild(themeToggle);
    themeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
    });

    // Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener("click", function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute("href")).scrollIntoView({
                behavior: "smooth"
            });
        });
    });

    // Animated Buttons
    document.querySelectorAll("button").forEach(button => {
        button.addEventListener("mouseover", () => {
            button.style.transform = "scale(1.1)";
        });
        button.addEventListener("mouseleave", () => {
            button.style.transform = "scale(1)";
        });
    });

    // Background Image Slideshow
    const images = ["bg1.jpg", "bg2.jpg", "bg3.jpg"];
    let index = 0;
    setInterval(() => {
        document.body.style.backgroundImage = `url(${images[index]})`;
        index = (index + 1) % images.length;
    }, 5000);

    // Typewriter Effect
    const typewriterText = "Welcome to Our Food Ordering Website!";
    let i = 0;
    function typeWriter() {
        if (i < typewriterText.length) {
            document.getElementById("typewriter").innerHTML += typewriterText.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        }
    }
    typeWriter();

    // Form Validation
    document.getElementById("signInForm").addEventListener("submit", (e) => {
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        if (!email.includes("@") || password.length < 6) {
            alert("Invalid email or password");
            e.preventDefault();
        }
    });

    // Live Search in Food Menu
    document.getElementById("search").addEventListener("input", function () {
        const query = this.value.toLowerCase();
        document.querySelectorAll(".food-item").forEach(item => {
            item.style.display = item.textContent.toLowerCase().includes(query) ? "block" : "none";
        });
    });

    // Interactive Food Cart
    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", () => {
            let total = parseFloat(document.getElementById("cart-total").innerText);
            total += parseFloat(button.dataset.price);
            document.getElementById("cart-total").innerText = total.toFixed(2);
        });
    });

    // Auto-Fill Location using Geolocation API
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            document.getElementById("location").value = `Lat: ${position.coords.latitude}, Lng: ${position.coords.longitude}`;
        });
    }

    // Floating Chat Widget
    const chatButton = document.createElement("button");
    chatButton.innerText = "Chat Support";
    chatButton.classList.add("chat-widget");
    document.body.appendChild(chatButton);
    chatButton.addEventListener("click", () => {
        alert("Support Chat Coming Soon!");
    });

    // Sticky Navbar
    window.addEventListener("scroll", () => {
        document.querySelector("nav").classList.toggle("sticky", window.scrollY > 50);
    });

    // Toast Notification Example
    function showToast(message) {
        const toast = document.createElement("div");
        toast.classList.add("toast");
        toast.innerText = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    showToast("Welcome to our website!");
});